package OOD.RestaurantReseverationSystem;

/**
 * Created by FLK on 2019-02-16.
 */
public class Server {
    private String serverId;
}
