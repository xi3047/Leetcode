package OOD.RestaurantReseverationSystem;

/**
 * Created by FLK on 2019-02-16.
 */
public class SmallTable extends BaseTable{

    public SmallTable(final String id){
        super(id,TableType.SMALL);
    }

}
