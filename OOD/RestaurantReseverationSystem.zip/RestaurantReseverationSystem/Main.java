package OOD.RestaurantReseverationSystem;

/**
 * Created by FLK on 2019-02-17.
 */
public class Main {

    public static void main(final String[] args){

    }
}
