package OOD.RestaurantReseverationSystem;

/**
 * Created by FLK on 2019-02-16.
 * The class that represent the large table
 */
public class LargeTable extends BaseTable {

    public LargeTable(final String id){
        super(id,TableType.LARGE);
    }
}
