package OOD.RestaurantReseverationSystem;

/**
 * Created by FLK on 2019-02-16.
 * This class is used to generate reservations
 */
public class Client {
    private final String id;

    public Client(final String id){
        this.id = id;
    }

    public String getId(){
        return id;
    }

    public Reservation makeReservation(){
        return null;
    }
}
