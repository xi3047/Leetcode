package OOD.Elevator;
// observer pattern
public interface ElevatorEventListener {
    void onElevetorStop();
}
