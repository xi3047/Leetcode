package OOD.Elevator;

public abstract class Button {
    private String id;

    protected int level;

    public Button(String id, int level) {
        this.id = id;
        this.level = level;
    }


}
